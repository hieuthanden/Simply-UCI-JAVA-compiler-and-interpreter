package runtime.heap;

import java.util.ArrayList;
import java.util.List;

import runtime.CallStack;

public class GC {
	private final Heap heap;
	@SuppressWarnings("unused")
	private final FreeList freeList;
	@SuppressWarnings("unused")
	private final CallStack stack;
	
	public GC(Heap heap, FreeList freeList, CallStack stack) {
		this.heap = heap;
		this.freeList = freeList;
		this.stack = stack;
	}

	public void collect() {
		// TODO: Homework Week 8: Implement
		throw new RuntimeException("GC not yet implemented");
	}
	
	@SuppressWarnings("unused")
	private Iterable<Pointer> getRootSet(CallStack callStack) {
		var list = new ArrayList<Pointer>();
		for (var frame : callStack) {
			collectPointers(frame.getParameters(), list);
			collectPointers(frame.getLocals(), list);
			collectPointers(frame.getEvaluationStack().toArray(), list);
			list.add(frame.getThisReference());
		}
		return list;
	}
	
	private void collectPointers(Object[] values, List<Pointer> list) {
		for (var value : values) {
			if (value instanceof Pointer) {
				list.add((Pointer) value);
			}
		}
	}

	@SuppressWarnings("unused")
	private void setMark(long block) {
		heap.writeLong64(block, heap.readLong64(block) | 0x8000000000000000L);
	}

	@SuppressWarnings("unused")
	private void clearMark(long block) {
		heap.writeLong64(block, heap.readLong64(block) & 0x7fffffffffffffffL);
	}

	@SuppressWarnings("unused")
	private boolean isMarked(long block) {
		return (heap.readLong64(block) & 0x8000000000000000L) != 0;
	}
}
