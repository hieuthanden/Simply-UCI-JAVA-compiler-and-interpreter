package runtime;

import java.util.Objects;
import java.util.Scanner;
import bytecode.Instruction;
import error.InvalidBytecodeException;
import error.VMException;
import runtime.descriptors.ArrayDescriptor;
import runtime.descriptors.ClassDescriptor;
import runtime.descriptors.FieldDescriptor;
import runtime.descriptors.MethodDescriptor;
import runtime.descriptors.TypeDescriptor;
import runtime.heap.Heap;
import runtime.heap.Pointer;

public class Interpreter {
	private final Loader loader;
	private final CallStack callStack = new CallStack();
	private final Heap heap;
	private final Scanner input = new Scanner(System.in);
	@SuppressWarnings("unused")
	private final boolean useJIT;
	
	public Interpreter(Loader loader, boolean useJIT) {
		Objects.requireNonNull(loader);
		this.loader = loader;
		heap = new Heap(callStack);
		this.useJIT = useJIT;
	}

	public void run() {
		setProgramEntry();
		while (!callStack.isEmpty()) {
			step();
		}
	}


	private void setProgramEntry() {
		var mainMethod = loader.getMainMethod();
		var mainClass = loader.getMainClass();
		if (mainMethod.getReturnType() != null || mainMethod.getParameterTypes().length != 0) {
			throw new InvalidBytecodeException("Invalid main method");
		}
		var mainObject = newObject(mainClass);
		invokeVirtual(mainMethod, mainObject, new Object[0]);
	}

	private void step() {
		var frame = activeFrame();
		var code = frame.getMethod().getCode();
		var pointer = frame.getInstructionPointer();
		if (pointer == code.length) {
			throw new VMException("Return statement missing");
		} else if (pointer < 0 || pointer >= code.length) {
			throw new InvalidBytecodeException("Invalid instruction pointer");
		}
		var instruction = code[pointer];
		frame.setInstructionPointer(pointer + 1); 
		execute(instruction);
	}

	private void execute(Instruction instruction) {
		var operand = instruction.getOperand();
		var locals = activeFrame().getLocals();
		var paras = activeFrame().getParameters();
		switch (instruction.getOpCode()) {
		case LDC:
			push(operand);
			break;
		case ACONST_NULL:
			// TODO: Implement
			push(null);
			break;
		case IADD:
			// TODO: Implement
			var iadd_right = checkInt(pop());
			var iadd_left = checkInt(pop());
			var iadd_result = (iadd_left + iadd_right);
			push(iadd_result);
			break;
		case ISUB:
			var isub_right = checkInt(pop());
			var isub_left = checkInt(pop());
			var isub_result = isub_left - isub_right;
			push(isub_result);
			// TODO: Implement
			break;
		case IMUL:
			// TODO: Implement
			var imul_right = checkInt(pop());
			var imul_left = checkInt(pop());
			var imul_result = imul_left * imul_right;
			push(imul_result);
			break;
		case IDIV:
			// TODO: Implement
			var idiv_right = checkInt(pop());
			var idiv_left = checkInt(pop());
			var idiv_result = idiv_left / idiv_right;
			push(idiv_result);
			break;
		case IREM:
			// TODO: Implement
			var irem_right = checkInt(pop());
			var irem_left = checkInt(pop());
			var irem_result = irem_left % irem_right;
			push(irem_result);
			break;
		case INEG:
			// TODO: Implement
			var ineg_value = checkInt(pop());
			var ineg_result =  - ineg_value;
			push(ineg_result);
			break;
		case BNEG:
			// TODO: Implement
			var bneg_value = checkBoolean(pop());
			var bneg_result = !(bneg_value);
			push(bneg_result);
			break;
		case CMPEQ:
			// TODO: Implement
			var eq_right = checkInt(pop());
			var eq_left = checkInt(pop());
			var eq_result = eq_left == eq_right;
			push(eq_result);
			break;
		case CMPNE:
			// TODO: Implement
			var ne_right = checkInt(pop());
			var ne_left = checkInt(pop());
			var ne_result = ne_left != ne_right;
			push(ne_result);
			break;
		case ICMPLT:
			// TODO: Implement
			var lt_right = checkInt(pop());
			var lt_left = checkInt(pop());
			var lt_result = lt_left < lt_right;
			push(lt_result);
			break;
		case ICMPLE:
			// TODO: Implement
			var le_right = checkInt(pop());
			var le_left = checkInt(pop());
			var le_result = le_left <= le_right;
			push(le_result);
			break;
		case ICMPGT:
			// TODO: Implement
			var gt_right = checkInt(pop());
			var gt_left = checkInt(pop());
			var gt_result = gt_left > gt_right;
			push(gt_result);
			break;
		case ICMPGE:
			// TODO: Implement
			var ge_right = checkInt(pop());
			var ge_left = checkInt(pop());
			var ge_result = ge_left >= ge_right;
			push(ge_result);
			break;
		case IF_TRUE:
			// TODO: Implement
			
			var true_frame = activeFrame();
			var true_pointer =  true_frame.getInstructionPointer();
			var true_condition = checkBoolean(pop()); // false
			if (true_condition) {
				 true_frame.setInstructionPointer ( true_pointer + (int)operand);
			}
			break;
		case IF_FALSE:
			// TODO: Implement
			var false_frame = activeFrame();
			var false_pointer = false_frame.getInstructionPointer();
			var false_condition = checkBoolean(pop()); // false
			if (!false_condition) {
				false_frame.setInstructionPointer(false_pointer + (int)operand);
			}
			break;
		case GOTO:
			// TODO: Implement
			var goto_frame = activeFrame();
			var goto_pointer = goto_frame.getInstructionPointer();
			goto_frame.setInstructionPointer(goto_pointer + (int)operand);
			break;
		case LOAD:
			// TODO: Implement
			var op_value = checkInt(operand);
			if (op_value == 0) {
				push(activeFrame().getThisReference());
			}
			else {
				if (op_value <= paras.length)
					push(paras[op_value - 1]);
				else
					push(locals[op_value - paras.length - 1]);
			}
			break;
		case STORE:
			// TODO: Implement
			var s_value = pop();
			locals[checkInt(operand) - 1] = s_value;
			break;
		case ALOAD:
			// TODO: Implement
			var ar_index = checkInt(pop());
			var ar_pointer = checkPointer(pop());
			var ar_value = heap.readElement(ar_pointer, ar_index);
			push(ar_value);
			break;
		case ASTORE:
			// TODO: Implement
			var a_value = pop();
			var a_index = checkInt(pop());
			var a_pointer = checkPointer(pop());
			heap.writeElement(a_pointer, a_index, a_value);
			break;
		case ARRAYLENGTH:
			// TODO: Implement
			var array_pointer = checkPointer(pop());
			var array_lenght = heap.getArrayLength(array_pointer);
			push(array_lenght);
			break;
		case INSTANCEOF:
			instanceofTest(operand);
			break;
		case CHECKCAST:
			checkCast(operand);
			break;
		case GETFIELD:
			getField(operand);
			break;
		case PUTFIELD:
			putField(operand);
			break;
		case NEW:
			newObject(operand);
			break;
		case NEWARRAY:
			newArray(operand);
			break;
		case INVOKESTATIC:
			invokeStatic(operand);
			break;
		case INVOKEVIRTUAL:
			invokeVirtual(operand);
			break;
		case RETURN:
			returnCall();
			break;
		default:
			throw new InvalidBytecodeException("Unsupported instruction opcode");
		}
	}
	


	private void returnCall() {
		var frame = activeFrame();
		var returnType = frame.getMethod().getReturnType();
		Object result = null;
		if (returnType != null) {
			if (frame.getEvaluationStack().isEmpty()) {
				throw new VMException("Return statement missing");
			}
			result = pop();
			checkType(result, returnType);
		}
		if (!frame.getEvaluationStack().isEmpty()) {
			throw new InvalidBytecodeException("Stack not empty on return");
		}
		callStack.pop();
		if (returnType != null) {
			push(result);
		}
	}
	
	private void newArray(Object operand) {
		if (!(operand instanceof ArrayDescriptor)) {
			throw new InvalidBytecodeException("newarray has no array type operand");
		}
		var arrayType = (ArrayDescriptor) operand;
		var length = checkInt(pop());
		if (length < 0) {
			throw new VMException("Negative array length");
		}
		var array = heap.allocateArray(arrayType, length);
		var defaultValue = defaultValue(arrayType.getElementType());
		for (int index = 0; index < length; index++) {
			heap.writeElement(array, index, defaultValue);
		}
		push(array);
	}

	private void instanceofTest(Object operand) {
		var instance = checkPointer(pop());
		if (instance == null) {
			push(false);
		} else {
			if (!(operand instanceof ClassDescriptor)) {
				throw new InvalidBytecodeException("instanceof has no class operand");
			}
			var targetType = (ClassDescriptor) operand;
			push(typeTest(instance, targetType));
		}
	}

	private void checkCast(Object operand) {
		var instance = checkPointer(pop());
		push(instance);
		if (!(operand instanceof ClassDescriptor)) {
			throw new InvalidBytecodeException("checkcast has no class operand");
		}
		var targetType = (ClassDescriptor) operand;
		if (!typeTest(instance, targetType)) {
			throw new VMException("Invalid cast");
		}
	}

	private void getField(Object operand) {
		if (!(operand instanceof FieldDescriptor)) {
			throw new InvalidBytecodeException("getfield has no field operand");
		}
		var field = (FieldDescriptor) operand;
		var instance = checkPointer(pop());
		if (instance == null) {
			throw new VMException("Null dereferenced");
		}
		var classType = getClassDescriptor(instance);
		var fieldTypes = classType.getAllFields();
		var index = field.getIndex();
		if (index < 0 || index >= fieldTypes.length || fieldTypes[index] != field) {
			throw new InvalidBytecodeException("Invalid field operand");
		}
		var value = heap.readField(instance, index);
		push(value);
	}

	private void putField(Object operand) {
		if (!(operand instanceof FieldDescriptor)) {
			throw new InvalidBytecodeException("putfield has no field operand");
		}
		var field = (FieldDescriptor) operand;
		var value = pop();
		var instance = checkPointer(pop());
		if (instance == null) {
			throw new VMException("Null dereferenced");
		}
		var classType = getClassDescriptor(instance);
		var allFields = classType.getAllFields();
		var index = field.getIndex();
		if (index < 0 || index >= allFields.length || allFields[index] != field) {
			throw new InvalidBytecodeException("Invalid field operand");
		}
		checkType(value, field.getType());
		heap.writeField(instance, index, value);
	}

	private void newObject(Object operand) {
		if (!(operand instanceof ClassDescriptor)) {
			throw new InvalidBytecodeException("new has no class operand");
		}
		var classType = (ClassDescriptor) operand;
		push(newObject(classType));
	}

	private Pointer newObject(ClassDescriptor type) {
		var newObject = heap.allocateObject(type);
		var fields = type.getAllFields();
		for (int index = 0; index < fields.length; index++) {
			heap.writeField(newObject, index, defaultValue(fields[index].getType()));
		}
		return newObject;
	}

	private void invokeVirtual(Object operand) {
		if (!(operand instanceof MethodDescriptor)) {
			throw new InvalidBytecodeException("invokevirtual has no method operand");
		}
		var staticMethod = (MethodDescriptor) operand;
		var parameterTypes = staticMethod.getParameterTypes();
		var arguments = new Object[parameterTypes.length];
		for (int index = arguments.length - 1; index >= 0; index--) {
			arguments[index] = pop();
			checkType(arguments[index], parameterTypes[index]);
		}
		var target = checkPointer(pop());
		invokeVirtual(staticMethod, target, arguments);
	}

	private void invokeVirtual(MethodDescriptor staticMethod, Pointer target, Object[] arguments) {
		if (target == null) {
			throw new VMException("Null dereferenced");
		}
		@SuppressWarnings("unused")
		var type = getClassDescriptor(target);
		// TODO: Homework Week 7: Implement virtual call
		var virtual_table =  type.getVirtualTable();
		var position = staticMethod.getPosition();
		var dynamicMethod = virtual_table[position];
		var locals = initLocals(staticMethod.getLocalTypes());
		callStack.push(new ActivationFrame(dynamicMethod, target, arguments, locals));
	}

	private Object[] initLocals(TypeDescriptor[] localTypes) {
		var variables = new Object[localTypes.length];
		for (int index = 0; index < localTypes.length; index++) {
			variables[index] = defaultValue(localTypes[index]);
		}
		return variables;
	}

	private void invokeStatic(Object operand) {
		if (operand == MethodDescriptor.HALT_METHOD) {
			var message = checkString(pop());
			throw new VMException("HALT: " + message);
		} else if (operand == MethodDescriptor.WRITE_INT_METHOD) {
			var value = checkInt(pop());
			System.out.print(value);
		} else if (operand == MethodDescriptor.WRITE_STRING_METHOD) {
			var value = checkString(pop());
			System.out.print(value + "\r\n");
		} else if (operand == MethodDescriptor.READ_INT_METHOD) {
			push(input.nextInt());
			input.nextLine();
		} else if (operand == MethodDescriptor.READ_STRING_METHOD) {
			push(input.nextLine());
		} else {
			throw new InvalidBytecodeException("invokestatic for undefined inbuilt method");
		}
	}

	private ClassDescriptor getClassDescriptor(Pointer instance) {
		var descriptor = heap.getDescriptor(instance);
		if (!(descriptor instanceof ClassDescriptor)) {
			throw new InvalidBytecodeException("Type mismatch");
		}
		return (ClassDescriptor) descriptor;
	}

	private Object defaultValue(TypeDescriptor type) {
		if (type == TypeDescriptor.BOOLEAN_TYPE) {
			return false;
		} else if (type == TypeDescriptor.INT_TYPE) {
			return 0;
		} else {
			return null;
		}
	}

	private void checkType(Object value, TypeDescriptor type) {
		if (type == TypeDescriptor.BOOLEAN_TYPE) {
			checkBoolean(value);
		} else if (type == TypeDescriptor.INT_TYPE) {
			checkInt(value);
		} else if (type == TypeDescriptor.STRING_TYPE) {
			checkString(value);
		} else if (!typeTest(checkPointer(value), type)) {
			throw new InvalidBytecodeException("Type mismatch");
		}
	}

	@SuppressWarnings("unused")
	private boolean typeTest(Pointer instance, TypeDescriptor targetType) {
		if (instance == null) {
			return true;
		}
		var sourceType = heap.getDescriptor(instance);
		if (sourceType == targetType) {
			return true;
		}
		if (!(sourceType instanceof ClassDescriptor && targetType instanceof ClassDescriptor)) {
			throw new InvalidBytecodeException("Type mismatch");
		}
		var sourceClass = (ClassDescriptor) sourceType;
		var targetClass = (ClassDescriptor) targetType;
		// TODO: Homework Week 7: Implement
		var ancestor_table = sourceClass.getAncestorTable();
		for (ClassDescriptor ances : ancestor_table)
		{
			if (ances == targetClass)
				return true;
		}
		return false;
		//throw new RuntimeException("not yet implemented");
	}

	private boolean checkBoolean(Object value) {
		if (!(value instanceof Boolean)) {
			throw new InvalidBytecodeException("Expected boolean instead of " + value);
		}
		return (boolean) value;
	}

	private int checkInt(Object value) {
		if (!(value instanceof Integer)) {
			throw new InvalidBytecodeException("Expected int instead of " + value);
		}
		return (int) value;
	}

	private String checkString(Object value) {
		if (value != null && !(value instanceof String)) {
			throw new InvalidBytecodeException("Expected string instead of " + value);
		}
		return (String) value;
	}
	
	private Pointer checkPointer(Object value) {
		if (value != null && !(value instanceof Pointer)) {
			throw new InvalidBytecodeException("Expected pointer instead of " + value);
		}
		return (Pointer) value;
	}

	private ActivationFrame activeFrame() {
		return callStack.peek();
	}

	private void push(Object value) {
		activeFrame().getEvaluationStack().push(value);
	}

	private Object pop() {
		return activeFrame().getEvaluationStack().pop();
	}
}
